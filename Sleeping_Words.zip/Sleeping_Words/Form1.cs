﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Threading;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Sleeping_Words
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        ///////////////////////////////////////////////////////////////////////////////////
        //static Microsoft.Speech.Synthesis.SpeechSynthesizer _MicrosoftSpeechSynthesizer;
        static System.Speech.Synthesis.SpeechSynthesizer _DesktopSpeechSynthesizer;
        static string[] LongName = new string[27];
        static string[] ShortName = new string[27];
        String[] DesktopSpeechName = new String[3]; // DesktopSpeechNameArray
        String VoiceName0_String = "";
        String VoiceName2_String = "";
        int Wordscounter = 0;
        String ListTextFile1_String = "";
        String ListTextFile2_String = "";
        String[] Word1_ArrayString = new String[50000];
        String[] Word2_ArrayString = new String[50000];
        DateTime time_start;
        DateTime time_now;
        TimeSpan ts;
        string ts_string;
        bool toStop = false;
        bool SpeakAsync_word1_done = false;
        bool SpeakAsync_word2_done = false;
        bool SpeakAsync_Separate_word1_done = false;
        int Speak_Rate_word1_i = 0;
        int Speak_Rate_word2_i = 0;
        int Speak_Rate_Separate_word1_i = -3;

        ///////////////////////////////////////////////////////////////////////////////////
        private void Form1_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;
            SpeechNameArray();
            DesktopSpeechNameArray();
            //_MicrosoftSpeechSynthesizer = new Microsoft.Speech.Synthesis.SpeechSynthesizer();
            _DesktopSpeechSynthesizer = new System.Speech.Synthesis.SpeechSynthesizer();

        }
        ///////////////////////////////////////////////////////////////////////////////////
        private void DesktopSpeechNameArray()
        {
            DesktopSpeechName[0] = "Microsoft David Desktop";
            DesktopSpeechName[1] = "Microsoft Zira Desktop";
            DesktopSpeechName[2] = "Microsoft Huihui Desktop";
            //Microsoft David Desktop
            //Microsoft Zira Desktop
            //Microsoft Huihui Desktop
        }
        ///
        private void SpeechNameArray()
        {
            LongName[0] = "Microsoft Server Speech Text to Speech Voice (ca-ES, Herena)"; ShortName[0] = "Catalan-Catalonian, Herena";
            LongName[1] = "Microsoft Server Speech Text to Speech Voice (da-DK, Helle)"; ShortName[1] = "Dandish-Denmark, Helle";
            LongName[2] = "Microsoft Server Speech Text to Speech Voice (de-DE, Hedda)"; ShortName[2] = "German-Germany, Hedda";
            LongName[3] = "Microsoft Server Speech Text to Speech Voice (en-AU, Hayley)"; ShortName[3] = "English-Australia, Hayley";
            LongName[4] = "Microsoft Server Speech Text to Speech Voice (en-CA, Heather)"; ShortName[4] = "English-Canada, Heather";
            LongName[5] = "Microsoft Server Speech Text to Speech Voice (en-GB, Hazel)"; ShortName[5] = "English-UK, Hazel";
            LongName[6] = "Microsoft Server Speech Text to Speech Voice (en-IN, Heera)"; ShortName[6] = "English-India, Heera";
            LongName[7] = "Microsoft Server Speech Text to Speech Voice (en-US, Helen)"; ShortName[7] = "English-US, Helen";
            LongName[8] = "Microsoft Server Speech Text to Speech Voice (en-US, ZiraPro)"; ShortName[8] = "English-US, ZiraPro";
            LongName[9] = "Microsoft Server Speech Text to Speech Voice (es-ES, Helena)"; ShortName[9] = "Spanish-Spain, Helena";
            LongName[10] = "Microsoft Server Speech Text to Speech Voice (es-MX, Hilda)"; ShortName[10] = "Spanish-Mexico, Hilda";
            LongName[11] = "Microsoft Server Speech Text to Speech Voice (fi-FI, Heidi)"; ShortName[11] = "Finnish-Finland, Heidi";
            LongName[12] = "Microsoft Server Speech Text to Speech Voice (fr-CA, Harmonie)"; ShortName[12] = "French-Canada, Harmonie";
            LongName[13] = "Microsoft Server Speech Text to Speech Voice (fr-FR, Hortense)"; ShortName[13] = "French-France, Hortense";
            LongName[14] = "Microsoft Server Speech Text to Speech Voice (it-IT, Lucia)"; ShortName[14] = "Italian-Italy, Lucia";
            LongName[15] = "Microsoft Server Speech Text to Speech Voice (ja-JP, Haruka)"; ShortName[15] = "Japanese-Japan, Haruka";
            LongName[16] = "Microsoft Server Speech Text to Speech Voice (ko-KR, Heami)"; ShortName[16] = "Korean-Korea, Heami";
            LongName[17] = "Microsoft Server Speech Text to Speech Voice (nb-NO, Hulda)"; ShortName[17] = "Norwegian-Norway, Hulda";
            LongName[18] = "Microsoft Server Speech Text to Speech Voice (nl-NL, Hanna)"; ShortName[18] = "Dutch-Netherlands, Hanna)";
            LongName[19] = "Microsoft Server Speech Text to Speech Voice (pl-PL, Paulina)"; ShortName[19] = "Polish-Poland, Paulina";
            LongName[20] = "Microsoft Server Speech Text to Speech Voice (pt-BR, Heloisa)"; ShortName[20] = "Portuguese-Brazil, Heloisa";
            LongName[21] = "Microsoft Server Speech Text to Speech Voice (pt-PT, Helia)"; ShortName[21] = "Portuguese-Portugal, Helia";
            LongName[22] = "Microsoft Server Speech Text to Speech Voice (ru-RU, Elena)"; ShortName[22] = "Russian-Russia, Elena";
            LongName[23] = "Microsoft Server Speech Text to Speech Voice (sv-SE, Hedvig)"; ShortName[23] = "Swedish-Sweden, Hedvig";
            LongName[24] = "Microsoft Server Speech Text to Speech Voice (zh-CN, HuiHui)"; ShortName[24] = "Chinese Simplified-CN, HuiHui";
            LongName[25] = "Microsoft Server Speech Text to Speech Voice (zh-HK, HunYee)"; ShortName[25] = "Chinese Cantonese";
            LongName[26] = "Microsoft Server Speech Text to Speech Voice (zh-TW, HanHan)"; ShortName[26] = "Chinese Mandarin";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        private void Button1_Click(object sender, EventArgs e)
        {

            ReadAloud_Asynchronous();
        }

        private void ReadAloud_Asynchronous()
        {
            time_start = DateTime.Now;
            timer_Time.Interval = 1000;
            timer_Time.Enabled = true;

            VoiceName0_String = DesktopSpeechName[0];
            VoiceName2_String = DesktopSpeechName[2];
            GetWordsFromTextFiles();

            toStop = false;
            Random ran = new Random();
            int n;
            String word1 = "";
            String word2 = "";
            //MessageBox.Show(Wordscounter.ToString());
            //System.Threading.Thread.Sleep(1000);

            for (int i = 0; i < 100000000; i++)
            {
                if (toStop == true) break;
                Application.DoEvents();
                n = ran.Next(0,Wordscounter);
                label1.Text = "index: " + n.ToString();
                label2.Text = "i: " + (i+1).ToString()+"/"+ Wordscounter.ToString();
                word1 = Word1_ArrayString[n];
                word2 = Word2_ArrayString[n];
                textBox1.Text = word1;
                textBox2.Text = word2;
                textBox1.Refresh();
                textBox2.Refresh();

                //System.Threading.Thread.Sleep(1000);
                _DesktopSpeechSynthesizer = new System.Speech.Synthesis.SpeechSynthesizer();
                _DesktopSpeechSynthesizer.SetOutputToDefaultAudioDevice();
                _DesktopSpeechSynthesizer.SelectVoice(VoiceName0_String);

                if (toStop == true) break;
                _DesktopSpeechSynthesizer.Rate = Speak_Rate_word1_i;
                SpeakAsync_word1_done = false;
                _DesktopSpeechSynthesizer.SpeakAsync(word1);
                _DesktopSpeechSynthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word1);
                while (SpeakAsync_word1_done == false)
                {
                    if (toStop == true) break;
                    Application.DoEvents();
                }

                if (toStop == true) break;
                _DesktopSpeechSynthesizer.Rate = Speak_Rate_word1_i;
                SpeakAsync_word1_done = false;
                _DesktopSpeechSynthesizer.SpeakAsync(word1);
                _DesktopSpeechSynthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word1);
                while (SpeakAsync_word1_done == false)
                {
                    if (toStop == true) break;
                    Application.DoEvents();
                }

                if (toStop == true) break;
                _DesktopSpeechSynthesizer.Rate = Speak_Rate_Separate_word1_i;
                SpeakAsync_Separate_word1_done = false;
                _DesktopSpeechSynthesizer.SpeakAsync(Separate_word(word1));
                _DesktopSpeechSynthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_Separate_word1);
                while (SpeakAsync_Separate_word1_done == false)
                {
                    if (toStop == true) break;
                    Application.DoEvents();
                }
                if (toStop == true) break;
                _DesktopSpeechSynthesizer.Rate = Speak_Rate_word1_i;
                SpeakAsync_word1_done = false;
                _DesktopSpeechSynthesizer.SpeakAsync(word1);
                _DesktopSpeechSynthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word1);
                while (SpeakAsync_word1_done == false)
                {
                    if (toStop == true) break;
                    Application.DoEvents();
                }
                /////*****************************************************************************
                _DesktopSpeechSynthesizer = new System.Speech.Synthesis.SpeechSynthesizer();
                _DesktopSpeechSynthesizer.SetOutputToDefaultAudioDevice();
                _DesktopSpeechSynthesizer.SelectVoice(VoiceName2_String);
                _DesktopSpeechSynthesizer.Rate = Speak_Rate_word2_i;
                if (toStop == true) break;
                SpeakAsync_word2_done = false;
                _DesktopSpeechSynthesizer.SpeakAsync(word2);
                _DesktopSpeechSynthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(SpeakCompleted_word2);
                while (SpeakAsync_word2_done == false)
                {
                    if (toStop == true) break;
                    Application.DoEvents();
                }
            }
            timer_Time.Enabled = false;
        }
        private void SpeakCompleted_word1(object sender, SpeakCompletedEventArgs e)
        {
            SpeakAsync_word1_done = true;
        }
        private void SpeakCompleted_Separate_word1(object sender, SpeakCompletedEventArgs e)
        {
            SpeakAsync_Separate_word1_done = true;
        }
        private void SpeakCompleted_word2(object sender, SpeakCompletedEventArgs e)
        {
            SpeakAsync_word2_done = true;
        }
        //////////////////////////////////////////////////////////////////////////////////////
        private void GetWordsFromTextFiles()
        {
            // Read the file and display it line by line.  
            Wordscounter = 0;
            int i = 0;
            int indexof = 0;
            string line = "";
            string line1 = "";
            string line2 = "";
            //System.IO.StreamReader file = new System.IO.StreamReader(@"D:\0Source\Sleeping_Words\Sleeping_Words\Words_New.txt");
            System.IO.StreamReader file = new System.IO.StreamReader(@"words.txt");
            while ((line = file.ReadLine()) != null)
            {
                indexof = 0;
                indexof = line.IndexOf("|");
                line1 = line.Substring(0, indexof);
                line2 = line.Substring(indexof + 1);
                Word1_ArrayString[i] = line1;
                Word2_ArrayString[i] = line2;
                i++;
                Wordscounter++;
            }
            file.Close();
        }
     ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
     //       private void GetWordsFromTwoFiles()
     //   {
     //       // Read the file and display it line by line.  
     //       Wordscounter = 0;
     //       int i = 0;
     //       string line1 = "";
     //       System.IO.StreamReader file1 = new System.IO.StreamReader(@"Words_New_.txt");
     //       while ((line1 = file1.ReadLine()) != null)
     //       {
     //           Word1_ArrayString[i] = line1;
     //           i++;
     //           Wordscounter++;
     //       }
     //       file1.Close();
     //   }
        //////////////////////////////////////////////////////////////////////////////////////
        private String Separate_word(String w)
        {
            int len = 0;
            w = w.Trim();
            len = w.Length;
            String sw = "";
            for (int i = 0; i < len; i++)
            {
                sw = sw + w.Substring(i, 1) + "..................";
            }
            sw = sw.TrimEnd();
            return sw;
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            toStop = true;
        }

        private void timer_Time_Tick(object sender, EventArgs e)
        {
            time_now = DateTime.Now;
            ts = time_now - time_start;
            ts_string = ts.ToString();
            ts_string = ts_string.Substring(0, 8);
            label_Timer.Text = ts_string;
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            toStop = true;
            System.Windows.Forms.Application.Exit();
        }

        private void timer_DateTime_Tick(object sender, EventArgs e)
        {
            label_DateTime.Text = DateTime.Now.ToString();
        }

        //////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////////////////////

    }
}
